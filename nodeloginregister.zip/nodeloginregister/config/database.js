module.exports = {
 'connection':{
  'host':'localhost',
  'user':'root',
  'password':'password'
 },
 'database':'mydb',
 'user_table':'users'
}